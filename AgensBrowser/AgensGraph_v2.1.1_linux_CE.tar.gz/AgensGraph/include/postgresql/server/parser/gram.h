
/* A Bison parser, made by GNU Bison 2.4.1.  */

/* Skeleton interface for Bison's Yacc-like parsers in C
   
      Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.
   
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.
   
   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */


/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     IDENT = 258,
     FCONST = 259,
     SCONST = 260,
     BCONST = 261,
     XCONST = 262,
     Op = 263,
     ICONST = 264,
     PARAM = 265,
     TYPECAST = 266,
     DOT_DOT = 267,
     COLON_EQUALS = 268,
     EQUALS_GREATER = 269,
     LESS_EQUALS = 270,
     GREATER_EQUALS = 271,
     NOT_EQUALS = 272,
     ADD_EQUALS = 273,
     ABORT_P = 274,
     ABSOLUTE_P = 275,
     ACCESS = 276,
     ACTION = 277,
     ADD_P = 278,
     ADMIN = 279,
     AFTER = 280,
     AGGREGATE = 281,
     ALL = 282,
     ALLSHORTESTPATHS = 283,
     ALSO = 284,
     ALTER = 285,
     ALWAYS = 286,
     ANALYSE = 287,
     ANALYZE = 288,
     AND = 289,
     ANY = 290,
     ARRAY = 291,
     AS = 292,
     ASC = 293,
     ASSERT = 294,
     ASSERTION = 295,
     ASSIGNMENT = 296,
     ASYMMETRIC = 297,
     AT = 298,
     ATTACH = 299,
     ATTRIBUTE = 300,
     AUTHORIZATION = 301,
     BACKWARD = 302,
     BEFORE = 303,
     BEGIN_P = 304,
     BETWEEN = 305,
     BIGINT = 306,
     BINARY = 307,
     BIT = 308,
     BOOLEAN_P = 309,
     BOTH = 310,
     BY = 311,
     CACHE = 312,
     CALLED = 313,
     CASCADE = 314,
     CASCADED = 315,
     CASE = 316,
     CAST = 317,
     CATALOG_P = 318,
     CHAIN = 319,
     CHAR_P = 320,
     CHARACTER = 321,
     CHARACTERISTICS = 322,
     CHECK = 323,
     CHECKPOINT = 324,
     CLASS = 325,
     CLOSE = 326,
     CLUSTER = 327,
     COALESCE = 328,
     COLLATE = 329,
     COLLATION = 330,
     COLUMN = 331,
     COLUMNS = 332,
     COMMENT = 333,
     COMMENTS = 334,
     COMMIT = 335,
     COMMITTED = 336,
     CONCURRENTLY = 337,
     CONFIGURATION = 338,
     CONFLICT = 339,
     CONNECTION = 340,
     CONSTRAINT = 341,
     CONSTRAINTS = 342,
     CONTAINS = 343,
     CONTENT_P = 344,
     CONTINUE_P = 345,
     CONVERSION_P = 346,
     COPY = 347,
     COST = 348,
     CREATE = 349,
     CROSS = 350,
     CSV = 351,
     CUBE = 352,
     CURRENT_P = 353,
     CURRENT_CATALOG = 354,
     CURRENT_DATE = 355,
     CURRENT_ROLE = 356,
     CURRENT_SCHEMA = 357,
     CURRENT_TIME = 358,
     CURRENT_TIMESTAMP = 359,
     CURRENT_USER = 360,
     CURSOR = 361,
     CYCLE = 362,
     DATA_P = 363,
     DATABASE = 364,
     DAY_P = 365,
     DEALLOCATE = 366,
     DEC = 367,
     DECIMAL_P = 368,
     DECLARE = 369,
     DEFAULT = 370,
     DEFAULTS = 371,
     DEFERRABLE = 372,
     DEFERRED = 373,
     DEFINER = 374,
     DELETE_P = 375,
     DELIMITER = 376,
     DELIMITERS = 377,
     DEPENDS = 378,
     DESC = 379,
     DETACH = 380,
     DICTIONARY = 381,
     DIJKSTRA = 382,
     DISABLE_P = 383,
     DISCARD = 384,
     DISTINCT = 385,
     DO = 386,
     DOCUMENT_P = 387,
     DOMAIN_P = 388,
     DOUBLE_P = 389,
     DROP = 390,
     EACH = 391,
     ELABEL = 392,
     ELSE = 393,
     ENABLE_P = 394,
     ENCODING = 395,
     ENCRYPTED = 396,
     END_P = 397,
     ENDS = 398,
     ENUM_P = 399,
     ESCAPE = 400,
     EVENT = 401,
     EXCEPT = 402,
     EXCLUDE = 403,
     EXCLUDING = 404,
     EXCLUSIVE = 405,
     EXECUTE = 406,
     EXISTS = 407,
     EXPLAIN = 408,
     EXTENSION = 409,
     EXTERNAL = 410,
     EXTRACT = 411,
     FALSE_P = 412,
     FAMILY = 413,
     FETCH = 414,
     FILTER = 415,
     FIRST_P = 416,
     FLOAT_P = 417,
     FOLLOWING = 418,
     FOR = 419,
     FORCE = 420,
     FOREIGN = 421,
     FORWARD = 422,
     FREEZE = 423,
     FROM = 424,
     FULL = 425,
     FUNCTION = 426,
     FUNCTIONS = 427,
     GENERATED = 428,
     GLOBAL = 429,
     GRANT = 430,
     GRANTED = 431,
     GRAPH = 432,
     GREATEST = 433,
     GROUP_P = 434,
     GROUPING = 435,
     HANDLER = 436,
     HAVING = 437,
     HEADER_P = 438,
     HOLD = 439,
     HOUR_P = 440,
     IDENTITY_P = 441,
     IF_P = 442,
     ILIKE = 443,
     IMMEDIATE = 444,
     IMMUTABLE = 445,
     IMPLICIT_P = 446,
     IMPORT_P = 447,
     IN_P = 448,
     INCLUDING = 449,
     INCREMENT = 450,
     INDEX = 451,
     INDEXES = 452,
     INHERIT = 453,
     INHERITS = 454,
     INITIALLY = 455,
     INLINE_P = 456,
     INNER_P = 457,
     INOUT = 458,
     INPUT_P = 459,
     INSENSITIVE = 460,
     INSERT = 461,
     INSTEAD = 462,
     INT_P = 463,
     INTEGER = 464,
     INTERSECT = 465,
     INTERVAL = 466,
     INTO = 467,
     INVOKER = 468,
     IS = 469,
     ISNULL = 470,
     ISOLATION = 471,
     JOIN = 472,
     KEY = 473,
     LABEL = 474,
     LANGUAGE = 475,
     LARGE_P = 476,
     LAST_P = 477,
     LATERAL_P = 478,
     LEADING = 479,
     LEAKPROOF = 480,
     LEAST = 481,
     LEFT = 482,
     LEVEL = 483,
     LIKE = 484,
     LIMIT = 485,
     LISTEN = 486,
     LOAD = 487,
     LOCAL = 488,
     LOCALTIME = 489,
     LOCALTIMESTAMP = 490,
     LOCATION = 491,
     LOCK_P = 492,
     LOCKED = 493,
     LOGGED = 494,
     MAPPING = 495,
     MATCH = 496,
     MATERIALIZED = 497,
     MAXVALUE = 498,
     MERGE = 499,
     METHOD = 500,
     MINUTE_P = 501,
     MINVALUE = 502,
     MODE = 503,
     MONTH_P = 504,
     MOVE = 505,
     NAME_P = 506,
     NAMES = 507,
     NATIONAL = 508,
     NATURAL = 509,
     NCHAR = 510,
     NEW = 511,
     NEXT = 512,
     NO = 513,
     NONE = 514,
     NOT = 515,
     NOTHING = 516,
     NOTIFY = 517,
     NOTNULL = 518,
     NOWAIT = 519,
     NULL_P = 520,
     NULLIF = 521,
     NULLS_P = 522,
     NUMERIC = 523,
     OBJECT_P = 524,
     OF = 525,
     OFF = 526,
     OFFSET = 527,
     OIDS = 528,
     OLD = 529,
     ON = 530,
     ONLY = 531,
     OPERATOR = 532,
     OPTION = 533,
     OPTIONAL_P = 534,
     OPTIONS = 535,
     OR = 536,
     ORDER = 537,
     ORDINALITY = 538,
     OUT_P = 539,
     OUTER_P = 540,
     OVER = 541,
     OVERLAPS = 542,
     OVERLAY = 543,
     OVERRIDING = 544,
     OWNED = 545,
     OWNER = 546,
     PARALLEL = 547,
     PARSER = 548,
     PARTIAL = 549,
     PARTITION = 550,
     PASSING = 551,
     PASSWORD = 552,
     PLACING = 553,
     PLANS = 554,
     POLICY = 555,
     POSITION = 556,
     PRECEDING = 557,
     PRECISION = 558,
     PRESERVE = 559,
     PREPARE = 560,
     PREPARED = 561,
     PRIMARY = 562,
     PRIOR = 563,
     PRIVILEGES = 564,
     PROCEDURAL = 565,
     PROCEDURE = 566,
     PROPERTY = 567,
     PROGRAM = 568,
     PUBLICATION = 569,
     QUOTE = 570,
     RANGE = 571,
     READ = 572,
     REAL = 573,
     REASSIGN = 574,
     RECHECK = 575,
     RECURSIVE = 576,
     REF = 577,
     REFERENCES = 578,
     REFERENCING = 579,
     REFRESH = 580,
     REINDEX = 581,
     RELATIVE_P = 582,
     RELEASE = 583,
     REMOVE = 584,
     RENAME = 585,
     REPEATABLE = 586,
     REPLACE = 587,
     REPLICA = 588,
     RESET = 589,
     RESTART = 590,
     RESTRICT = 591,
     RETURN = 592,
     RETURNING = 593,
     RETURNS = 594,
     REVOKE = 595,
     RIGHT = 596,
     ROLE = 597,
     ROLLBACK = 598,
     ROLLUP = 599,
     ROW = 600,
     ROWS = 601,
     RULE = 602,
     SAVEPOINT = 603,
     SCHEMA = 604,
     SCHEMAS = 605,
     SCROLL = 606,
     SEARCH = 607,
     SECOND_P = 608,
     SECURITY = 609,
     SELECT = 610,
     SEQUENCE = 611,
     SEQUENCES = 612,
     SERIALIZABLE = 613,
     SERVER = 614,
     SESSION = 615,
     SESSION_USER = 616,
     SET = 617,
     SETS = 618,
     SETOF = 619,
     SHARE = 620,
     SHORTESTPATH = 621,
     SHOW = 622,
     SIMILAR = 623,
     SIMPLE = 624,
     SINGLE = 625,
     SIZE_P = 626,
     SKIP = 627,
     SMALLINT = 628,
     SNAPSHOT = 629,
     SOME = 630,
     SQL_P = 631,
     STABLE = 632,
     STANDALONE_P = 633,
     START = 634,
     STARTS = 635,
     STATEMENT = 636,
     STATISTICS = 637,
     STDIN = 638,
     STDOUT = 639,
     STORAGE = 640,
     STRICT_P = 641,
     STRIP_P = 642,
     SUBSCRIPTION = 643,
     SUBSTRING = 644,
     SYMMETRIC = 645,
     SYSID = 646,
     SYSTEM_P = 647,
     TABLE = 648,
     TABLES = 649,
     TABLESAMPLE = 650,
     TABLESPACE = 651,
     TEMP = 652,
     TEMPLATE = 653,
     TEMPORARY = 654,
     TEXT_P = 655,
     THEN = 656,
     TIME = 657,
     TIMESTAMP = 658,
     TO = 659,
     TRAILING = 660,
     TRANSACTION = 661,
     TRANSFORM = 662,
     TREAT = 663,
     TRIGGER = 664,
     TRIM = 665,
     TRUE_P = 666,
     TRUNCATE = 667,
     TRUSTED = 668,
     TYPE_P = 669,
     TYPES_P = 670,
     UNBOUNDED = 671,
     UNCOMMITTED = 672,
     UNENCRYPTED = 673,
     UNION = 674,
     UNIQUE = 675,
     UNKNOWN = 676,
     UNLISTEN = 677,
     UNLOGGED = 678,
     UNTIL = 679,
     UPDATE = 680,
     USER = 681,
     USING = 682,
     VACUUM = 683,
     VALID = 684,
     VALIDATE = 685,
     VALIDATOR = 686,
     VALUE_P = 687,
     VALUES = 688,
     VARCHAR = 689,
     VARIADIC = 690,
     VARYING = 691,
     VERBOSE = 692,
     VERSION_P = 693,
     VIEW = 694,
     VIEWS = 695,
     VLABEL = 696,
     VOLATILE = 697,
     WHEN = 698,
     WHERE = 699,
     WHITESPACE_P = 700,
     WINDOW = 701,
     WITH = 702,
     WITHIN = 703,
     WITHOUT = 704,
     WORK = 705,
     WRAPPER = 706,
     WRITE = 707,
     XML_P = 708,
     XMLATTRIBUTES = 709,
     XMLCONCAT = 710,
     XMLELEMENT = 711,
     XMLEXISTS = 712,
     XMLFOREST = 713,
     XMLNAMESPACES = 714,
     XMLPARSE = 715,
     XMLPI = 716,
     XMLROOT = 717,
     XMLSERIALIZE = 718,
     XMLTABLE = 719,
     YEAR_P = 720,
     YES_P = 721,
     ZONE = 722,
     NOT_LA = 723,
     NULLS_LA = 724,
     WITH_LA = 725,
     POSTFIXOP = 726,
     UMINUS = 727,
     EQUALS_TILDE = 728
   };
#endif



#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
{

/* Line 1676 of yacc.c  */
#line 214 "gram.y"

	core_YYSTYPE		core_yystype;
	/* these fields must match core_YYSTYPE: */
	int					ival;
	char				*str;
	const char			*keyword;

	char				chr;
	bool				boolean;
	JoinType			jtype;
	DropBehavior		dbehavior;
	OnCommitAction		oncommit;
	List				*list;
	Node				*node;
	Value				*value;
	ObjectType			objtype;
	TypeName			*typnam;
	FunctionParameter   *fun_param;
	FunctionParameterMode fun_param_mode;
	ObjectWithArgs		*objwithargs;
	DefElem				*defelt;
	SortBy				*sortby;
	WindowDef			*windef;
	JoinExpr			*jexpr;
	IndexElem			*ielem;
	Alias				*alias;
	RangeVar			*range;
	IntoClause			*into;
	WithClause			*with;
	InferClause			*infer;
	OnConflictClause	*onconflict;
	A_Indices			*aind;
	ResTarget			*target;
	struct PrivTarget	*privtarget;
	AccessPriv			*accesspriv;
	struct ImportQual	*importqual;
	InsertStmt			*istmt;
	VariableSetStmt		*vsetstmt;
	PartitionElem		*partelem;
	PartitionSpec		*partspec;
	PartitionBoundSpec	*partboundspec;
	RoleSpec			*rolespec;



/* Line 1676 of yacc.c  */
#line 571 "gram.h"
} YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
#endif



#if ! defined YYLTYPE && ! defined YYLTYPE_IS_DECLARED
typedef struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
} YYLTYPE;
# define yyltype YYLTYPE /* obsolescent; will be withdrawn */
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif



