/* src/include/port/hpux.h */

/* nothing needed */
